#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>

using namespace cv;
using namespace std;

int main() {
    Mat cameraMatrix = (Mat_<double>(3, 3) << 
        2334.3100677892139, 0, 722.62133349286796, 
        0, 2335.8999103578203, 534.62083305548731, 
        0, 0, 1);
    
    Mat distCoeffs = (Mat_<double>(1, 5) << 
        -0.080008805450534709, 
        0.085675034453367591, 
        0.0027903039462225331, 
        -0.0007315334877910064, 
        0);

    string videoPath = "video/video.avi"; 
    VideoCapture cap(videoPath);
    
    if (!cap.isOpened()) {
        cerr << "Error: Cannot open video." << endl;
        return -1;
    }

    int frame_width = cap.get(CAP_PROP_FRAME_WIDTH);
    int frame_height = cap.get(CAP_PROP_FRAME_HEIGHT);
    VideoWriter writer("output.avi", VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, Size(frame_width, frame_height));

    float board_width = 135.0;
    float board_height = 56.0;
    vector<Point3f> object_points = {
        {-board_width/2, -board_height/2, 0},
        {board_width/2, -board_height/2, 0},
        {board_width/2, board_height/2, 0},
        {-board_width/2, board_height/2, 0}
    };

    while (true) {
        Mat frame;
        cap >> frame;
        if (frame.empty()) break;

        double t_start = (double)getTickCount();

        Mat hsv, mask_red1, mask_red2, mask_red;
        cvtColor(frame, hsv, COLOR_BGR2HSV);
        
        inRange(hsv, Scalar(0, 100, 100), Scalar(10, 255, 255), mask_red1);
        inRange(hsv, Scalar(160, 100, 100), Scalar(180, 255, 255), mask_red2);
        mask_red = mask_red1 | mask_red2;

        vector<vector<Point>> contours;
        findContours(mask_red, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        for (size_t i = 0; i < contours.size(); i++) {
            double area = contourArea(contours[i]);
            if (area > 200 && area < 10000) {
                RotatedRect rect = minAreaRect(contours[i]);
                
                float ratio = max(rect.size.width, rect.size.height) / min(rect.size.width, rect.size.height);
                if (ratio > 1.2 && ratio < 3.5) {
                    Point2f pts[4];
                    rect.points(pts);
                    
                    for (int j = 0; j < 4; j++) {
                        line(frame, pts[j], pts[(j + 1) % 4], Scalar(0, 255, 0), 2);
                    }

                    vector<Point2f> image_points = {pts[0], pts[1], pts[2], pts[3]};
                    Mat rvec, tvec;
                    solvePnP(object_points, image_points, cameraMatrix, distCoeffs, rvec, tvec);

                    if (!tvec.empty()) {
                        string text = "X:" + to_string(tvec.at<double>(0,0)).substr(0,4) + 
                                      " Y:" + to_string(tvec.at<double>(1,0)).substr(0,4) +
                                      " Z:" + to_string(tvec.at<double>(2,0)).substr(0,4);
                        putText(frame, text, Point(pts[0].x, pts[0].y - 10), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 255), 2);
                    }
                }
            }
        }

        double t_end = (double)getTickCount();
        double duration = (t_end - t_start) / getTickFrequency() * 1000.0;
        string timeText = "Time: " + to_string(duration).substr(0,5) + " ms";
        putText(frame, timeText, Point(20, 40), FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 0, 255), 2);

        writer.write(frame);
        imshow("Detection", frame);
        
        if (waitKey(1) == 'q') break;
    }

    cap.release();
    writer.release();
    destroyAllWindows();
    return 0;
}