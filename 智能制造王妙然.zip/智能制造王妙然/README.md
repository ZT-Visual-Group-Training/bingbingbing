# 视觉组考核（自瞄方向）

## 1. 运行环境
- **操作系统**：Ubuntu 22.04
- **编程语言**：C++
- **依赖库**：OpenCV 4.x

## 2. 安装步骤与运行命令
在包含 `main.cpp` 的目录下，执行以下命令：

**编译代码：**
```bash
g++ main.cpp -o main `pkg-config --cflags --libs opencv4`