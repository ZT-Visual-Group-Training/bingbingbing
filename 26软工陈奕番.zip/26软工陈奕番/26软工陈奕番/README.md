这是传统视觉基础流程(装甲板自瞄)
任务有经ai完善细节过，但本自瞄系统由本人独立完成架构设计与核心流程推导，模块基于对具体技术栈的完整理解后手动实现
（其中从命令行读取视频，检查路径相关的部分由ai负责完成）

#项目结构
1.从命令行读取视频、相机内参和输出路径，加载并检查相机标定数据。
2.打开视频，检查视频与标定分辨率是否符合程序要求（1440×1080），并创建 AVI 和 CSV 输出。
3.逐帧处理视频：按颜色分割灯条区域，经过形态学处理后提取轮廓。
4.根据轮廓的长宽比、倾角等条件筛选灯条，再按位置和尺寸关系配对。
5.对候选配对进行评分，选出装甲板并计算四个角点。
6.用角点和装甲板尺寸进行 PnP 位姿解算，再根据深度和重投影误差检查结果。
//滤波
7.将装甲板框、角点、位姿和耗时绘制到帧上，写入输出视频；检测数据逐帧写入 CSV。
8.处理结束后关闭文件并输出帧数、检测数量和处理速度统计。

# 项目运行 

运行环境：Ubuntu 22.04、GCC 11、C++17、CMake 3.16 及以上、OpenCV 4.5.4。

进入项目根目录后配置并编译：

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j"$(nproc)"

运行第一组数据：

```bash
DATA=2026-11-13_18-25-25_462305/2026-11-13_18-25-25_462305
./build/auto_aim \
  --video "$DATA/video/video.avi" \
  --calibration "$DATA/calibration/intrinsics.yaml" \
  --output results/first_run.avi

运行第二组数据：

```bash
DATA=2026-11-13_18-28-12_830451/2026-11-13_18-28-12_830451
./build/auto_aim \
  --video "$DATA/video/video.avi" \
  --calibration "$DATA/calibration/intrinsics.yaml" \
  --output results/second_run.avi
  
  
  运行结果放在result文件夹里
