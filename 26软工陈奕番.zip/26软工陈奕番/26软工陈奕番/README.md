这是传统视觉基础流程(装甲板自瞄)
任务有经ai完善细节过，但本自瞄系统由本人独立完成架构设计与核心流程推导，模块基于对具体技术栈的完整理解后手动实现
（其中从命令行读取视频，检查路径相关的部分由ai负责完成）

# 项目运行

运行环境：Ubuntu 22.04、GCC 11、C++17、CMake 3.16 及以上、OpenCV 4.5.4。

进入项目根目录后配置并编译：

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j"$(nproc)"

运行第一组数据：

```bash
DATA=2026-11-13_18-25-25_462305/2026-11-13_18-25-25_462305
./build/auto_aim \
  --video "$DATA/video/video.avi" \
  --calibration "$DATA/calibration/intrinsics.yaml" \
  --output results/first_run.avi

运行第二组数据：

```bash
DATA=2026-11-13_18-28-12_830451/2026-11-13_18-28-12_830451
./build/auto_aim \
  --video "$DATA/video/video.avi" \
  --calibration "$DATA/calibration/intrinsics.yaml" \
  --output results/second_run.avi
