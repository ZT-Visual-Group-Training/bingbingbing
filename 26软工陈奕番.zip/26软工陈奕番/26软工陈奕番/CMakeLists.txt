cmake_minimum_required(VERSION 3.16)
project(robomaster_auto_aim VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(OpenCV REQUIRED COMPONENTS core imgproc videoio highgui calib3d)
add_executable(auto_aim src/main.cpp)
target_include_directories(auto_aim PRIVATE include ${OpenCV_INCLUDE_DIRS})
target_link_libraries(auto_aim PRIVATE ${OpenCV_LIBS})
target_compile_options(auto_aim PRIVATE -Wall -Wextra -Wpedantic)
