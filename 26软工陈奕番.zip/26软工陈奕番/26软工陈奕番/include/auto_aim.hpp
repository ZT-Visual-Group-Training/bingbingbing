#pragma once

#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace armor {

enum class Color { Red, Blue };
enum class ColorMode { Both, Red, Blue };
enum class ArmorSize { Small, Large };
enum class SizeMode { Auto, Small, Large };

struct CameraParameters {
    cv::Mat camera_matrix;
    cv::Mat distort_coeffs;
    cv::Size image_size{1440, 1080};
};
CameraParameters loadCalibration(const std::string& path);

struct DetectorConfig {
    ColorMode color = ColorMode::Both;
    SizeMode size = SizeMode::Auto;
    bool recover_bright_cores = true; 
    bool check_pair_content = true; 
    cv::Size open_kernel{1, 3}; 
    cv::Size close_kernel{9, 3}; 
    double min_contour_area = 50.0;
    double min_light_aspect = 3.0;
    double max_tilt_deg = 30.0;
    double min_fill_ratio = 0.5;
    double max_angle_diff_deg = 10.0;
    double max_height_diff_ratio = 0.2; 
    double min_pair_distance_ratio = 0.7; 
    double max_pair_distance_ratio = 5.0;
    double max_vertical_offset_ratio = 0.4; 
    double large_armor_ratio = 3.2; 
    double max_pair_skew_deg = 15.0; 
};
struct ColorMask { Color color; cv::Mat mask; };
struct ContourCandidate { Color color; std::vector<cv::Point> points; double area; };
struct LightBar {
    Color color;
    cv::Point2f center, top, bottom;
    double length = 0.0, width = 0.0, tilt_deg = 0.0;
};
struct LightPair { std::size_t left, right; ArmorSize size; double score; };
struct ArmorDetection {
    Color color;
    ArmorSize size;
    
    std::array<cv::Point2f, 4> corners;
    cv::Point2f center;
    double light_length = 0.0;
};
struct DetectionDiagnostics {
    std::vector<ContourCandidate> contours;
    std::vector<LightBar> lights;
    std::vector<LightPair> pairs;
};
class ArmorDetector {
public:
    explicit ArmorDetector(DetectorConfig config = {});
    std::vector<ArmorDetection> detect(const cv::Mat& bgr) const;
    DetectionDiagnostics diagnose(const cv::Mat& bgr) const;
private:
    DetectorConfig config_;
    std::vector<ColorMask> segment(const cv::Mat& bgr) const;
    std::vector<ColorMask> morph(const std::vector<ColorMask>& masks) const;
    std::vector<ContourCandidate> contours(const std::vector<ColorMask>& masks) const;
    std::vector<LightBar> lights(const std::vector<ContourCandidate>& contours) const;
    std::vector<LightPair> pair(const std::vector<LightBar>& lights, const cv::Mat& bgr) const;
    std::vector<ArmorDetection> corners(const std::vector<LightBar>& lights,
                                        const std::vector<LightPair>& pairs) const;
};

struct PoseOutput {
    bool valid = false;
    cv::Vec3d rvec{0., 0., 0.};
    cv::Vec3d tvec{0., 0., 0.}; 
    double reprojection_error_px = 0.0;
};
std::vector<cv::Point3d> modelPoints(ArmorSize size);
PoseOutput estimatePose(const ArmorDetection& armor, const CameraParameters& camera);

struct TargetResult {
    ArmorDetection armor;
    PoseOutput pose;
};

cv::Mat drawTargets(const cv::Mat& bgr, const std::vector<TargetResult>& targets);
void drawTiming(cv::Mat& frame, double processing_ms, double processing_fps);

class AnnotatedVideoWriter {
public:
    AnnotatedVideoWriter(const std::string& path, cv::Size size = {1440, 1080}, double fps = 165.0);
    void write(const cv::Mat& frame);
    void close();
private:
    cv::VideoWriter writer_;
    cv::Size size_;
};

struct Options {
    std::string video, calibration, output, csv;
    DetectorConfig detector;
    bool show = false, help = false;
    std::uint64_t max_frames = 0; 
    int threads = 2; 
};
Options parseOptions(int argc, char** argv);
std::string usage();
const char* colorName(Color color);
const char* sizeName(ArmorSize size);

} 
